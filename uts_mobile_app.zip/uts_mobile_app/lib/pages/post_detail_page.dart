import 'package:flutter/material.dart';

import 'comment_page.dart';
import 'post_list_page.dart';

class PostDetailPage extends StatelessWidget {
  final Post post;

  const PostDetailPage({super.key, required this.post});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Detail Post")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(post.title,
                style: const TextStyle(
                    fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text(post.body),
            const Spacer(),
            Center(
              child: ElevatedButton(
                child: const Text('Lihat Komentar'),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CommentPage(postId: post.id),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
